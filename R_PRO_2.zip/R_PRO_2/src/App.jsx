
import './App.css'
import Footer from './componets/FOOTER/Footer'
import Hero from './componets/Hero/Hero'
import Nav from './componets/NAV/Nav'

function App() {


  return (
    <>
     <Nav/>
     <Hero/>
     <Footer/>
    </>
  )
}

export default App
